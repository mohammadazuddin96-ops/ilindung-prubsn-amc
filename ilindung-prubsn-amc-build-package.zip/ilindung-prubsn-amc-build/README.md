# iLindung PruBSN AMC — Supabase Auth build

This package updates the application login to use the existing Supabase Auth user and `public.admin_users` registry.

## Required server environment variables

- `SUPABASE_URL`: `https://megngtkyigtmitxkqaqx.supabase.co`
- `SUPABASE_PUBLISHABLE_KEY`: the project's `sb_publishable_...` key
- `DATABASE_URL`: PostgreSQL session-pooler URI. Keep the database password private and set this only as a server-side secret.
- `PGSSLMODE`: `require`
- `PORT`: `8080` (container default)

Do not put `DATABASE_URL` or a database password in frontend files, public repository files, or chat messages.

## Database

The `backend/db/schema.sql` file documents the schema and policies. The existing Supabase project has already had these tables and policies created in the prior setup. Do not rerun it unless a fresh project is being initialized or the schema has been reviewed.

The backend verifies the Supabase access token with Supabase Auth and then checks that the authenticated user's ID exists in `public.admin_users` with role `admin`. The PostgreSQL connection is used only by the server.

## Build

Build the OCI image from this directory using the included `Dockerfile`. Required environment variables must be configured securely in the hosting runtime before the application can pass its health check.
