# iLindung PruBSN AMC — Build package

This is an application source package for local build and deployment preparation.
It is **not yet deployed** and is not connected to the customer's production database.

## Architecture
- `frontend/`: responsive single-page site, agent microsites, and protected admin interface.
- `backend/`: Express API with PostgreSQL adapter and SQL schema.
- The frontend is served by Express in production so the app can be deployed as one stateless OCI image.
- PostgreSQL is external/persistent; set `DATABASE_URL` only in the hosting environment.

## Local setup
1. Install Node.js 20+ and PostgreSQL 15+.
2. Copy `backend/.env.example` to `backend/.env`.
3. Set `DATABASE_URL`, `JWT_SECRET`, `ADMIN_USERNAME`, and `ADMIN_PASSWORD_HASH`.
4. Create a database and apply `backend/db/schema.sql`.
5. From `backend/`, run `npm install`, then `npm run dev`.
6. Open `http://localhost:8080`; admin is at `/admin`.

Generate a password hash (never commit the plaintext password):
```bash
node -e "require('bcryptjs').hash('YOUR_LONG_UNIQUE_PASSWORD', 12).then(console.log)"
```

## Routes
- `/` public marketing landing page
- `/agent/:code` agent microsite
- `/admin` admin sign-in and management UI
- `/api/health` health endpoint
- `/api/admin/login`, `/api/admin/agents` protected admin API
- `/api/agents/:code` public agent profile

## Agent data
The admin can create/edit/activate/deactivate/delete agents. Fields: code, name, WhatsApp, photo URL, active state.
WhatsApp links are generated from the agent's own number.
No sales-proof upload, sales-verification status, or agent self-service login is included.

## Important production checklist
- Set a strong unique admin password hash and JWT secret in the hosting secret store.
- Restrict admin login attempts at the edge / reverse proxy.
- Use HTTPS only; set secure cookies if session handling is changed.
- Configure PostgreSQL backups and least-privilege DB credentials.
- Confirm product wording, disclaimers, logos, and regulatory approvals with the business owner before launch.
- Do not store KWSP credentials, OTPs, or sensitive customer financial information.
- Test admin CRUD, agent routing, WhatsApp destinations, and database recovery before public launch.

## Deployment limitation
JOMVI's current interface accepts static source or a prebuilt OCI image digest for Express containers.
This source package is not an OCI image and no production image has been built or pushed to a registry.


## Validation performed in this build session
- `node --check frontend/app.js`: passed.
- `node --check backend/src/server.js`: passed.
- Source integrity checks for frontend entry, admin CRUD routes, public agent route, SQL schema, and Dockerfile: passed.
- Not performed: dependency installation, production build, live API/database integration tests, penetration/security tests, OCI image build/push, and JOMVI deployment.


## OCI build path (GitHub Actions)
- `.github/workflows/publish-ghcr.yml` builds the Dockerfile and pushes an OCI image to GitHub Container Registry (GHCR) whenever `main` is updated or the workflow is run manually.
- The workflow uses GitHub's temporary `GITHUB_TOKEN`; no registry password is placed in the source.
- The first published GHCR package may default to private. Before JOMVI can pull it, the repository owner must set the package visibility to Public (or arrange an operator-approved pull method).
- Copy the immutable `ghcr.io/...@sha256:...` digest from the workflow summary. Do not use the mutable `:latest` tag for JOMVI deployment.
- This workflow is prepared but has NOT been run. It requires the owner to upload this source to a GitHub repository and run GitHub Actions.
