-- iLindung PruBSN AMC database schema
-- Safe to run on the existing project: uses IF NOT EXISTS and replaces only named policies.

CREATE TABLE IF NOT EXISTS public.agents (
  id BIGSERIAL PRIMARY KEY,
  code VARCHAR(32) NOT NULL UNIQUE,
  name VARCHAR(160) NOT NULL,
  whatsapp VARCHAR(32) NOT NULL,
  photo_url TEXT,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS agents_active_idx ON public.agents(active);

CREATE TABLE IF NOT EXISTS public.admin_users (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'admin' CHECK (role = 'admin'),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.agents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can view active agents" ON public.agents;
CREATE POLICY "Public can view active agents"
  ON public.agents FOR SELECT TO anon, authenticated
  USING (active = TRUE);

DROP POLICY IF EXISTS "Admins can manage agents" ON public.agents;
CREATE POLICY "Admins can manage agents"
  ON public.agents FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.admin_users
      WHERE user_id = auth.uid() AND role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.admin_users
      WHERE user_id = auth.uid() AND role = 'admin'
    )
  );

DROP POLICY IF EXISTS "Admin can read own record" ON public.admin_users;
CREATE POLICY "Admin can read own record"
  ON public.admin_users FOR SELECT TO authenticated
  USING (user_id = auth.uid());

GRANT SELECT ON public.agents TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.agents TO authenticated;
GRANT USAGE, SELECT ON SEQUENCE public.agents_id_seq TO authenticated;
GRANT SELECT ON public.admin_users TO authenticated;
