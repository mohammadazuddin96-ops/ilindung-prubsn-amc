import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import pg from 'pg';
import path from 'path';
import { fileURLToPath } from 'url';

const app=express(), {Pool}=pg;
const port=Number(process.env.PORT||8080);
const pool=process.env.DATABASE_URL?new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.PGSSLMODE==='require'?{rejectUnauthorized:false}:undefined}):null;
const __dirname=path.dirname(fileURLToPath(import.meta.url));
const frontend=path.resolve(__dirname,'../../frontend');
app.use(helmet({contentSecurityPolicy:false}));
app.use(cors({origin:false}));
app.use(express.json({limit:'100kb'}));
app.get('/api/health',async(_req,res)=>{try{if(pool)await pool.query('SELECT 1');res.json({ok:true,database:pool?'connected':'not_configured'})}catch{res.status(503).json({ok:false,database:'unavailable'})}});
function requireDb(res){if(!pool){res.status(503).json({error:'Database belum dikonfigurasi'});return false}return true}
function auth(req,res,next){try{const t=(req.headers.authorization||'').replace(/^Bearer\\s+/i,'');req.admin=jwt.verify(t,process.env.JWT_SECRET);next()}catch{return res.status(401).json({error:'Sesi admin tidak sah'})}}
app.post('/api/admin/login',async(req,res)=>{const {username,password}=req.body||{};if(!process.env.ADMIN_PASSWORD_HASH||!process.env.JWT_SECRET)return res.status(503).json({error:'Kredensial admin belum dikonfigurasi'});const ok=username===process.env.ADMIN_USERNAME&&await bcrypt.compare(String(password||''),process.env.ADMIN_PASSWORD_HASH);if(!ok)return res.status(401).json({error:'Username atau kata laluan salah'});res.json({token:jwt.sign({sub:username,role:'admin'},process.env.JWT_SECRET,{expiresIn:'8h'})})});
app.get('/api/admin/agents',auth,async(_req,res)=>{if(!requireDb(res))return;try{const q=await pool.query('SELECT code,name,whatsapp,photo_url,active FROM agents ORDER BY code');res.json(q.rows)}catch{res.status(500).json({error:'Tidak dapat membaca rekod'})}});
app.post('/api/admin/agents',auth,async(req,res)=>{if(!requireDb(res))return;const {code,name,whatsapp,photo_url=''}=req.body||{};if(!/^[A-Za-z0-9_-]{3,32}$/.test(code||'')||!name?.trim()||!whatsapp?.trim())return res.status(400).json({error:'Kod, nama dan WhatsApp diperlukan'});try{const q=await pool.query(`INSERT INTO agents(code,name,whatsapp,photo_url) VALUES($1,$2,$3,$4) ON CONFLICT(code) DO UPDATE SET name=EXCLUDED.name,whatsapp=EXCLUDED.whatsapp,photo_url=EXCLUDED.photo_url,updated_at=NOW() RETURNING *`,[code.trim(),name.trim(),whatsapp.trim(),photo_url.trim()]);res.json(q.rows[0])}catch{res.status(500).json({error:'Tidak dapat menyimpan rekod'})}});
app.patch('/api/admin/agents/:code/toggle',auth,async(req,res)=>{if(!requireDb(res))return;try{const q=await pool.query('UPDATE agents SET active=NOT active,updated_at=NOW() WHERE code=$1 RETURNING code,active',[req.params.code]);if(!q.rowCount)return res.status(404).json({error:'Wakil tidak ditemui'});res.json(q.rows[0])}catch{res.status(500).json({error:'Tidak dapat mengubah status'})}});
app.delete('/api/admin/agents/:code',auth,async(req,res)=>{if(!requireDb(res))return;try{const q=await pool.query('DELETE FROM agents WHERE code=$1',[req.params.code]);res.json({deleted:q.rowCount===1})}catch{res.status(500).json({error:'Tidak dapat memadam rekod'})}});
app.get('/api/agents/:code',async(req,res)=>{if(!requireDb(res))return;try{const q=await pool.query('SELECT code,name,whatsapp,photo_url FROM agents WHERE code=$1 AND active=TRUE',[req.params.code]);if(!q.rowCount)return res.status(404).json({error:'Not found'});res.json(q.rows[0])}catch{res.status(500).json({error:'Service unavailable'})}});
app.use(express.static(frontend));
app.get(['/admin','/admin/','/agent/:code'],(_req,res)=>res.sendFile(path.join(frontend,'index.html')));
app.listen(port,'0.0.0.0',()=>console.log(`iLindung AMC listening on ${port}`));
