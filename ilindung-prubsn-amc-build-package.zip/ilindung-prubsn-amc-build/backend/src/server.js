import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import pg from 'pg';
import path from 'path';
import { fileURLToPath } from 'url';
import { createClient } from '@supabase/supabase-js';

const app = express();
const { Pool } = pg;
const port = Number(process.env.PORT || 8080);
const supabaseUrl = process.env.SUPABASE_URL;
const supabasePublishableKey = process.env.SUPABASE_PUBLISHABLE_KEY;
const databaseUrl = process.env.DATABASE_URL;

const supabase = (supabaseUrl && supabasePublishableKey)
  ? createClient(supabaseUrl, supabasePublishableKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
        detectSessionInUrl: false
      }
    })
  : null;

const pool = databaseUrl
  ? new Pool({
      connectionString: databaseUrl,
      ssl: process.env.PGSSLMODE === 'disable'
        ? false
        : { rejectUnauthorized: false },
      max: 5,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 10000
    })
  : null;

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const frontend = path.resolve(__dirname, '../../frontend');

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: false }));
app.use(express.json({ limit: '100kb' }));

function requireServices(res) {
  if (!pool || !supabase) {
    res.status(503).json({ error: 'Sambungan database atau Supabase Auth belum dikonfigurasi' });
    return false;
  }
  return true;
}

async function requireAdmin(req, res, next) {
  if (!requireServices(res)) return;
  const authorization = req.headers.authorization || '';
  const token = authorization.replace(/^Bearer\s+/i, '').trim();
  if (!token) return res.status(401).json({ error: 'Sesi admin diperlukan' });

  try {
    const { data, error } = await supabase.auth.getUser(token);
    if (error || !data?.user) {
      return res.status(401).json({ error: 'Sesi admin tidak sah atau telah tamat' });
    }

    const result = await pool.query(
      `SELECT role FROM public.admin_users WHERE user_id = $1 AND role = 'admin' LIMIT 1`,
      [data.user.id]
    );
    if (result.rowCount !== 1) {
      return res.status(403).json({ error: 'Akaun ini tidak mempunyai akses Admin AMC' });
    }

    req.adminUser = data.user;
    return next();
  } catch {
    return res.status(503).json({ error: 'Tidak dapat mengesahkan akses admin' });
  }
}

app.get('/api/health', async (_req, res) => {
  const config = { auth: Boolean(supabase), database: Boolean(pool) };
  try {
    if (pool) await pool.query('SELECT 1');
    res.json({ ok: config.auth && config.database, ...config, databaseStatus: pool ? 'connected' : 'not_configured' });
  } catch {
    res.status(503).json({ ok: false, ...config, databaseStatus: 'unavailable' });
  }
});

app.post('/api/admin/login', async (req, res) => {
  if (!supabase) {
    return res.status(503).json({ error: 'Supabase Auth belum dikonfigurasi pada server' });
  }
  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ error: 'Email dan kata laluan diperlukan' });
  }
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email: String(email).trim(),
      password: String(password)
    });
    if (error || !data?.session?.access_token) {
      return res.status(401).json({ error: 'Email atau kata laluan tidak betul' });
    }
    return res.json({ token: data.session.access_token });
  } catch {
    return res.status(503).json({ error: 'Tidak dapat menghubungi Supabase Auth' });
  }
});

app.get('/api/admin/agents', requireAdmin, async (_req, res) => {
  try {
    const result = await pool.query(
      'SELECT code, name, whatsapp, photo_url, active FROM public.agents ORDER BY code'
    );
    return res.json(result.rows);
  } catch {
    return res.status(500).json({ error: 'Tidak dapat membaca rekod ejen' });
  }
});

app.post('/api/admin/agents', requireAdmin, async (req, res) => {
  const { code, name, whatsapp, photo_url = '' } = req.body || {};
  if (!/^[A-Za-z0-9_-]{3,32}$/.test(code || '') || !name?.trim() || !whatsapp?.trim()) {
    return res.status(400).json({ error: 'Kod, nama dan WhatsApp diperlukan' });
  }
  try {
    const result = await pool.query(
      `INSERT INTO public.agents (code, name, whatsapp, photo_url)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (code) DO UPDATE SET
         name = EXCLUDED.name,
         whatsapp = EXCLUDED.whatsapp,
         photo_url = EXCLUDED.photo_url,
         updated_at = NOW()
       RETURNING code, name, whatsapp, photo_url, active`,
      [code.trim(), name.trim(), whatsapp.trim(), String(photo_url || '').trim()]
    );
    return res.json(result.rows[0]);
  } catch {
    return res.status(500).json({ error: 'Tidak dapat menyimpan rekod ejen' });
  }
});

app.patch('/api/admin/agents/:code/toggle', requireAdmin, async (req, res) => {
  try {
    const result = await pool.query(
      `UPDATE public.agents SET active = NOT active, updated_at = NOW()
       WHERE code = $1 RETURNING code, active`,
      [req.params.code]
    );
    if (!result.rowCount) return res.status(404).json({ error: 'Ejen tidak ditemui' });
    return res.json(result.rows[0]);
  } catch {
    return res.status(500).json({ error: 'Tidak dapat mengubah status ejen' });
  }
});

app.delete('/api/admin/agents/:code', requireAdmin, async (req, res) => {
  try {
    const result = await pool.query('DELETE FROM public.agents WHERE code = $1', [req.params.code]);
    return res.json({ deleted: result.rowCount === 1 });
  } catch {
    return res.status(500).json({ error: 'Tidak dapat memadam rekod ejen' });
  }
});

app.get('/api/agents/:code', async (req, res) => {
  if (!pool) return res.status(503).json({ error: 'Database belum dikonfigurasi' });
  try {
    const result = await pool.query(
      `SELECT code, name, whatsapp, photo_url FROM public.agents
       WHERE code = $1 AND active = TRUE LIMIT 1`,
      [req.params.code]
    );
    if (!result.rowCount) return res.status(404).json({ error: 'Not found' });
    return res.json(result.rows[0]);
  } catch {
    return res.status(503).json({ error: 'Service unavailable' });
  }
});

app.use(express.static(frontend));
app.get(['/admin', '/admin/', '/agent/:code'], (_req, res) => {
  res.sendFile(path.join(frontend, 'index.html'));
});

app.listen(port, '0.0.0.0', () => {
  console.log(`iLindung AMC listening on ${port}`);
});
